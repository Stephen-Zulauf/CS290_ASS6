import Order from '../order.mjs';

const database = [
      new Order('ORCL', 87),
      new Order('MSFT', 44)
];

export default database;